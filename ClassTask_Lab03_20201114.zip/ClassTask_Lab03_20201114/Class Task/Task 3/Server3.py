import socket
import threading

data = 16
format = "utf-8"
port = 5050
device_name = socket.gethostname()
server_ip = socket.gethostbyname(device_name)
server_socket_addr = (server_ip, port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(server_socket_addr)

server.listen()
print("Out server is listening...")

def client_handle(server_socket, client_add):
    print("Connected to",client_add)
    connected = True
    while connected:
        upcoming_message_length = server_socket.recv(data).decode(format)
        print("Upcoming message length is ",upcoming_message_length)
        if upcoming_message_length:
            message = server_socket.recv(int(upcoming_message_length)).decode(format)
            print(message)
           
            if message == "disconnect":
                print("Disconnected with", client_add)
                connected = False
            count = 0 
            for i in message:
              if i.lower() == "a" or i.lower() == "e" or i.lower() == "i" or i.lower() == "o" or i.lower() == "u":
                   count += 1
            if count < 2:
                out = "Not enough vowels"

            elif count == 2:
                out = "Enough vowels I guess"
            
            elif count > 2:
                out = "Too many vowels"

            server_socket.send(out.encode(format))

    server_socket.close()
          


while True:
    server_socket, client_add = server.accept()
    thread = threading.Thread(target=client_handle, args=(server_socket, client_add))
    thread.start()
    