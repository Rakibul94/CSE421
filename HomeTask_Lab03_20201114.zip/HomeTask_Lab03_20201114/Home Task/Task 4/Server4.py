import socket

data = 16
format = "utf-8"
port = 5050
device_name = socket.gethostname()
server_ip = socket.gethostbyname(device_name)
server_socket_addr = (server_ip, port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(server_socket_addr)

server.listen()
print("Out server is listening...")


while True:
    server_socket, client_add = server.accept()
    print("Connected to",client_add)
    connected = True
    while connected:
        upcoming_message_length = server_socket.recv(data).decode(format)
        print("Upcoming message length is ",upcoming_message_length)
        if upcoming_message_length:
            message = server_socket.recv(int(upcoming_message_length)).decode(format)
            print(message)
           
            if message == "disconnect":
                print("Disconnected with", client_add)
                connected = False
            salary = 0 

            if int(message) <= 40:
                salary += int(message)*200
            elif int(message) > 40:
                salary += 8000 + 300*(int(message)-40)
            

            server_socket.send(str(salary).encode(format))

    server_socket.close()
          